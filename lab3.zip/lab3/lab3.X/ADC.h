#ifndef __ADC_H
#define	__ADC_H
#include <xc.h> 
#include <stdint.h>

unsigned Canal_ADC(unsigned short x);
void config_ADC(void);

#endif	/* __ADC_H_ */